@extends('layouts.app')

@section('title', 'Inicio')

@section('content')
    <h1 class="text-3xl font-bold">Bienvenido, Nacho 👋</h1>
@endsection
