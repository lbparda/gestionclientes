<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Expediente: <?php echo e($expediente->NºExpediente); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="bg-gray-100 text-gray-800 p-8">
    <div class="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow-md">
        <h1 class="text-3xl font-bold text-gray-800 mb-6">Editando Expediente</h1>
        <p class="text-lg font-mono text-indigo-600 mb-6 border-b pb-4"><?php echo e($expediente->NºExpediente); ?></p>
        <form action="<?php echo e(route('expedientes.update', $expediente->NºExpediente)); ?>" method="POST" class="space-y-6">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <?php
                $camposEditables = ['Titulo', 'FechaEx', 'Materia'];
                $camposBooleanos = ['Terminado', 'Facturado', 'Cobrado'];
                $camposTextoLargo = ['Observaciones'];
            ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <?php $__currentLoopData = $camposEditables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <label for="<?php echo e($campo); ?>" class="block text-sm font-medium text-gray-700"><?php echo e($campo); ?></label>
                        <input type="text" name="<?php echo e($campo); ?>" value="<?php echo e(old($campo, $expediente->$campo)); ?>" class="mt-1 block w-full border border-gray-300 rounded-md py-2 px-3">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $camposBooleanos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <label for="<?php echo e($campo); ?>" class="block text-sm font-medium text-gray-700"><?php echo e($campo); ?></label>
                        <select name="<?php echo e($campo); ?>" class="mt-1 block w-full border border-gray-300 rounded-md py-2 px-3">
                            <option value="1" <?php if($expediente->$campo): ?> selected <?php endif; ?>>Sí</option>
                            <option value="0" <?php if(!$expediente->$campo): ?> selected <?php endif; ?>>No</option>
                        </select>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="space-y-4 mt-6">
                <?php $__currentLoopData = $camposTextoLargo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <label for="<?php echo e($campo); ?>" class="block text-sm font-medium text-gray-700"><?php echo e($campo); ?></label>
                        <textarea name="<?php echo e($campo); ?>" rows="4" class="mt-1 block w-full border border-gray-300 rounded-md py-2 px-3"><?php echo e(old($campo, $expediente->$campo)); ?></textarea>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="flex justify-end space-x-2 mt-8 border-t pt-6">
                <a href="<?php echo e(route('expedientes.show', $expediente->NºExpediente)); ?>" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold px-5 py-2 rounded-md transition">Cancelar</a>
                <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-5 py-2 rounded-md transition">💾 Guardar Cambios</button>
            </div>
        </form>
    </div>
</body>
</html>
<?php /**PATH D:\DesarrolloWeb\laravel\gestionclientes\resources\views/clientes/expedientes/edit.blade.php ENDPATH**/ ?>